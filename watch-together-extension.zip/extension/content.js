// 一起看 —— 内容脚本
//
// 注入到 B站/腾讯/爱奇艺 页面里，做三件事：
// 1. 找到页面里正在播放的 <video> 元素
// 2. 连上你部署的 WebSocket 中转服务
// 3. 本地播放/暂停/拖动进度时，把动作同步给对方；收到对方动作时作用到本地视频
//
// 防回声：applyingRemote 标志。作用远端指令到本地 video 时会触发本地的
// play/pause/seeked 事件，如果不加标志会又把这个事件发回去，形成死循环。

(() => {
  'use strict';

  const state = {
    ws: null,
    room: null,
    serverUrl: null,
    connected: false,
    applyingRemote: false, // 硬锁：同步执行的一瞬间，屏蔽即时触发的本地事件
    video: null,
    reconnectTimer: null,
    // 回声抑制：记录"刚从对方应用了什么状态"。在 until 之前，本地触发的、
    // 与这个状态一致的事件都视为回声（不是我主动操作），不再发回，避免来回弹。
    // 只靠时间锁不行——seek 缓冲是异步的，事件可能几百毫秒后才触发。
    echo: { until: 0, time: 0, paused: null },
  };

  const now = () => Date.now();

  // 判断本地这次事件是不是"由刚收到的远端指令引起的回声"
  function isEcho(kind, v) {
    if (state.applyingRemote) return true;       // 正在同步执行，必然是回声
    if (now() > state.echo.until) return false;  // 窗口外，是真实的本地操作
    // 窗口内：只有"与刚应用的远端状态一致"才算回声；状态真的变了就放行
    if (kind === 'play') return state.echo.paused === false;
    if (kind === 'pause') return state.echo.paused === true;
    if (kind === 'seek') return Math.abs(v.currentTime - state.echo.time) < 1.0;
    return false;
  }

  // ---------- 找 video 元素 ----------
  // 三家平台的播放器都是标准 HTML5 <video>，但可能在 iframe 里、可能延迟加载。
  // 用轮询找到时长 > 0 的那个 video（通常就是正片）。
  function findVideo() {
    const videos = Array.from(document.querySelectorAll('video'));
    // 优先选正在播放或有时长的
    const candidate =
      videos.find((v) => v.duration > 0 && !v.paused) ||
      videos.find((v) => v.duration > 0) ||
      videos[0];
    return candidate || null;
  }

  function ensureVideo() {
    const v = findVideo();
    if (v && v !== state.video) {
      state.video = v;
      bindVideoEvents(v);
      log('已绑定视频元素');
    }
    return state.video;
  }

  // ---------- 监听本地视频动作，同步给对方 ----------
  function bindVideoEvents(v) {
    v.addEventListener('play', () => {
      if (isEcho('play', v)) return;
      send({ type: 'play', time: v.currentTime });
    });
    v.addEventListener('pause', () => {
      if (isEcho('pause', v)) return;
      send({ type: 'pause', time: v.currentTime });
    });
    // seeked：用户拖动进度条后触发。exact=true 表示明确的跳转意图，对方要精确对齐。
    v.addEventListener('seeked', () => {
      if (isEcho('seek', v)) return;
      send({ type: 'seek', time: v.currentTime, paused: v.paused, exact: true });
    });
  }

  // ---------- 把远端指令作用到本地视频 ----------
  function applyRemote(msg) {
    const v = ensureVideo();
    if (!v) return;

    // 记录回声窗口：接下来这段时间里，本地触发的、与此状态一致的 play/pause/seeked
    // 都是"由这次远端指令引起的"，不再发回。窗口给足 1.5 秒，覆盖 seek 缓冲的异步延迟。
    state.echo.until = now() + 1500;
    if (typeof msg.time === 'number') state.echo.time = msg.time;
    if (msg.type === 'play') state.echo.paused = false;
    else if (msg.type === 'pause') state.echo.paused = true;
    else if (msg.type === 'seek') state.echo.paused = !!msg.paused;

    state.applyingRemote = true;
    try {
      // 跳转（拖进度条）要精确对齐：阈值 0.3 秒。播放/暂停顺带的时间校正容差 0.8 秒。
      const threshold = msg.exact ? 0.3 : 0.8;
      if (typeof msg.time === 'number' && Math.abs(v.currentTime - msg.time) > threshold) {
        v.currentTime = msg.time;
      }
      if (msg.type === 'play') {
        v.play().catch(() => {});
        addMessage('sys', '对方点了播放 ▶');
      } else if (msg.type === 'pause') {
        v.pause();
        addMessage('sys', '对方按了暂停 ⏸');
      } else if (msg.type === 'seek') {
        if (msg.paused) v.pause();
        else v.play().catch(() => {});
        addMessage('sys', '对方跳到了 ' + fmtTime(msg.time));
      }
    } finally {
      // 硬锁只保护"同步执行的这一瞬间"里立刻同步触发的事件；
      // 之后异步触发的（如 seeked）交给 echo 窗口的状态匹配去判断。
      setTimeout(() => {
        state.applyingRemote = false;
      }, 50);
    }
  }

  // 秒数转 mm:ss
  function fmtTime(sec) {
    if (typeof sec !== 'number' || isNaN(sec)) return '';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  }

  // 收到对方发来的"打开这个页面"。已在同一页则忽略；否则跳转前保存好房间配置，
  // 让跳转后的新页面能靠 autoJoin 自动重连，聊天面板和同步会自动恢复。
  function handleOpenUrl(url) {
    if (!url) return;
    // 归一化对比：忽略 hash 等细枝末节
    const strip = (u) => u.split('#')[0];
    if (strip(url) === strip(location.href)) {
      addMessage('sys', '对方想一起看这页，你已经在这了');
      return;
    }
    buildPanel();
    addMessage('sys', '对方邀请你打开新页面，即将跳转…');
    // 确保当前房间配置已持久化（跳转后新页面自动重连需要）
    chrome.storage?.local?.set?.({
      serverUrl: state.serverUrl,
      room: state.room,
      pass: state.pass || '',
      autoJoin: true,
    });
    setTimeout(() => {
      location.href = url;
    }, 800);
  }


  // ---------- WebSocket 连接 ----------
  function connect() {
    if (!state.serverUrl || !state.room) return;
    if (state.ws && (state.ws.readyState === 0 || state.ws.readyState === 1)) return;

    state.manualLeave = false;
    const url =
      `${state.serverUrl}?room=${encodeURIComponent(state.room)}` +
      `&pass=${encodeURIComponent(state.pass || '')}`;
    log('连接中：' + url);

    let ws;
    try {
      ws = new WebSocket(url);
    } catch (e) {
      log('连接失败：' + e.message);
      scheduleReconnect();
      return;
    }
    state.ws = ws;

    ws.onopen = () => {
      state.connected = true;
      log('已连接到中转服务');
      buildPanel();
      addMessage('sys', '已连接，等待对方加入…');
      notifyPopup();
    };

    ws.onmessage = (ev) => {
      let msg;
      try {
        msg = JSON.parse(ev.data);
      } catch {
        return;
      }
      if (msg.type === 'presence') {
        const prev = state.peerCount || 0;
        state.peerCount = msg.count;
        if (msg.count >= 2 && prev < 2) addMessage('sys', '对方已加入 💕');
        else if (msg.count < 2 && prev >= 2) addMessage('sys', '对方离开了');
        notifyPopup();
        return;
      }
      if (msg.type === 'chat') {
        addMessage('peer', msg.text);
        return;
      }
      if (msg.type === 'openurl') {
        handleOpenUrl(msg.url);
        return;
      }
      applyRemote(msg);
    };

    ws.onclose = () => {
      state.connected = false;
      notifyPopup();
      scheduleReconnect();
    };

    ws.onerror = () => {
      // onclose 会紧跟着触发，重连逻辑统一放那里
    };
  }

  function scheduleReconnect() {
    if (state.reconnectTimer) return;
    state.reconnectTimer = setTimeout(() => {
      state.reconnectTimer = null;
      connect();
    }, 3000);
  }

  function send(msg) {
    if (state.ws && state.ws.readyState === 1) {
      state.ws.send(JSON.stringify(msg));
    }
  }

  function disconnect() {
    state.manualLeave = true;
    if (state.ws) {
      try { state.ws.close(); } catch {}
      state.ws = null;
    }
    state.connected = false;
    clearTimeout(state.reconnectTimer);
    state.reconnectTimer = null;
    // 主动离开时移除面板
    if (panel.root) {
      panel.root.remove();
      panel.root = null;
    }
  }


  // ---------- 可拖动聊天面板 ----------
  // 停在角落，显示历史对话，可拖到任意位置（位置记忆），可收起。
  // 面板自带输入框，直接在页面上就能发消息，不必每次开插件弹窗。
  const panel = { root: null, body: null, input: null, collapsed: false };

  function buildPanel() {
    if (panel.root) return;

    const root = document.createElement('div');
    root.style.cssText =
      'position:fixed;z-index:2147483647;width:260px;' +
      'background:rgba(28,28,30,.92);color:#fff;border-radius:12px;' +
      'font-family:-apple-system,"PingFang SC",sans-serif;font-size:13px;' +
      'box-shadow:0 6px 24px rgba(0,0,0,.4);overflow:hidden;' +
      'backdrop-filter:blur(6px);user-select:none;';

    // 标题栏（可拖动）
    const bar = document.createElement('div');
    bar.style.cssText =
      'display:flex;align-items:center;justify-content:space-between;' +
      'padding:8px 12px;background:#fb7299;cursor:move;font-weight:600;';
    bar.innerHTML =
      '<span>💬 一起看</span>' +
      '<span style="display:flex;gap:10px;align-items:center">' +
      '<span data-act="openurl" title="让对方打开你当前的视频页" ' +
      'style="cursor:pointer;opacity:.95;font-size:12px">🔗 拉对方过来</span>' +
      '<span data-act="toggle" style="cursor:pointer;opacity:.9">—</span>' +
      '</span>';

    // 消息区
    const body = document.createElement('div');
    body.style.cssText =
      'max-height:240px;min-height:60px;overflow-y:auto;padding:10px 12px;' +
      'display:flex;flex-direction:column;gap:6px;';

    // 输入区
    const foot = document.createElement('div');
    foot.style.cssText = 'display:flex;gap:6px;padding:8px;background:rgba(255,255,255,.06);';
    const input = document.createElement('input');
    input.placeholder = '说点什么…';
    input.style.cssText =
      'flex:1;border:none;border-radius:6px;padding:7px 9px;font-size:13px;' +
      'background:rgba(255,255,255,.12);color:#fff;outline:none;';
    input.setAttribute('placeholder', '说点什么…');
    const sendBtn = document.createElement('button');
    sendBtn.textContent = '发送';
    sendBtn.style.cssText =
      'border:none;border-radius:6px;padding:0 12px;background:#fb7299;' +
      'color:#fff;font-size:13px;cursor:pointer;';

    foot.appendChild(input);
    foot.appendChild(sendBtn);
    root.appendChild(bar);
    root.appendChild(body);
    root.appendChild(foot);
    document.documentElement.appendChild(root);

    panel.root = root;
    panel.body = body;
    panel.input = input;
    panel.foot = foot;

    // 恢复上次位置，默认右下角
    const pos = loadPanelPos();
    root.style.left = pos.left;
    root.style.top = pos.top;

    // 输入时阻止按键冒泡到播放器（否则空格会暂停视频、方向键会快进）
    ['keydown', 'keyup', 'keypress'].forEach((ev) =>
      input.addEventListener(ev, (e) => e.stopPropagation())
    );
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') submitChat();
    });
    sendBtn.addEventListener('click', submitChat);

    // 收起/展开
    bar.querySelector('[data-act="toggle"]').addEventListener('click', (e) => {
      e.stopPropagation();
      togglePanel();
    });

    // 拉对方过来：把当前页 URL 发给对方，让 TA 的浏览器跳到同一页
    bar.querySelector('[data-act="openurl"]').addEventListener('click', (e) => {
      e.stopPropagation();
      send({ type: 'openurl', url: location.href });
      addMessage('sys', '已把当前页发给对方');
    });

    enableDrag(root, bar);

    // 若当前正处于全屏，面板要挂到全屏元素里才可见
    relocatePanel();
  }

  function submitChat() {
    const text = panel.input.value.trim();
    if (!text) return;
    send({ type: 'chat', text });
    addMessage('me', text);
    panel.input.value = '';
  }

  function togglePanel() {
    panel.collapsed = !panel.collapsed;
    panel.body.style.display = panel.collapsed ? 'none' : 'flex';
    panel.foot.style.display = panel.collapsed ? 'none' : 'flex';
  }

  // 拖动：按住标题栏移动整个面板，松手记忆位置
  function enableDrag(root, handle) {
    let sx, sy, ox, oy, dragging = false;
    handle.addEventListener('mousedown', (e) => {
      dragging = true;
      sx = e.clientX; sy = e.clientY;
      const r = root.getBoundingClientRect();
      ox = r.left; oy = r.top;
      e.preventDefault();
    });
    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      let nl = ox + (e.clientX - sx);
      let nt = oy + (e.clientY - sy);
      // 限制在视口内
      nl = Math.max(0, Math.min(nl, window.innerWidth - root.offsetWidth));
      nt = Math.max(0, Math.min(nt, window.innerHeight - root.offsetHeight));
      root.style.left = nl + 'px';
      root.style.top = nt + 'px';
    });
    document.addEventListener('mouseup', () => {
      if (!dragging) return;
      dragging = false;
      savePanelPos(root.style.left, root.style.top);
    });
  }

  function loadPanelPos() {
    try {
      const raw = localStorage.getItem('watchTogetherPanelPos');
      if (raw) return JSON.parse(raw);
    } catch {}
    return { left: window.innerWidth - 280 + 'px', top: window.innerHeight - 360 + 'px' };
  }
  function savePanelPos(left, top) {
    try {
      localStorage.setItem('watchTogetherPanelPos', JSON.stringify({ left, top }));
    } catch {}
  }

  // 追加一条消息。who: 'me' | 'peer' | 'sys'
  function addMessage(who, text) {
    buildPanel();
    if (panel.collapsed) togglePanel(); // 有新消息自动展开
    const row = document.createElement('div');
    const isMe = who === 'me';
    const isSys = who === 'sys';
    if (isSys) {
      row.style.cssText = 'align-self:center;color:#aaa;font-size:11px;';
      row.textContent = text;
    } else {
      row.style.cssText =
        'max-width:80%;padding:6px 10px;border-radius:10px;word-break:break-word;' +
        (isMe
          ? 'align-self:flex-end;background:#fb7299;color:#fff;'
          : 'align-self:flex-start;background:rgba(255,255,255,.15);color:#fff;');
      row.textContent = text;
    }
    panel.body.appendChild(row);
    panel.body.scrollTop = panel.body.scrollHeight;
  }

  // ---------- 和 popup 通信 ----------
  function notifyPopup() {
    chrome.runtime?.sendMessage?.({
      type: 'status',
      connected: state.connected,
      room: state.room,
      peerCount: state.peerCount || 0,
    }).catch(() => {});
  }

  chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.type === 'join') {
      state.serverUrl = req.serverUrl;
      state.room = req.room;
      state.pass = req.pass;
      disconnect();
      connect();
      sendResponse({ ok: true });
    } else if (req.type === 'leave') {
      disconnect();
      notifyPopup();
      sendResponse({ ok: true });
    } else if (req.type === 'getStatus') {
      sendResponse({
        connected: state.connected,
        room: state.room,
        peerCount: state.peerCount || 0,
        hasVideo: !!ensureVideo(),
      });
    } else if (req.type === 'chat') {
      send({ type: 'chat', text: req.text });
      addMessage('me', req.text);
      sendResponse({ ok: true });
    }
    return true; // 异步 sendResponse
  });

  // ---------- 全屏适配 ----------
  // 进入全屏后，浏览器只渲染全屏元素及其子树，挂在 documentElement 下的面板会被隐藏。
  // 所以全屏时把面板移进全屏元素内部，退出时移回来。面板是 position:fixed，
  // 仍以视口定位，移动后位置不受影响。
  function relocatePanel() {
    if (!panel.root) return;
    const fsEl =
      document.fullscreenElement || document.webkitFullscreenElement || null;
    const target = fsEl || document.documentElement;
    if (panel.root.parentNode !== target) {
      target.appendChild(panel.root);
    }
  }
  ['fullscreenchange', 'webkitfullscreenchange'].forEach((ev) =>
    document.addEventListener(ev, relocatePanel)
  );

  // ---------- 启动 ----------
  // 页面里的 video 可能延迟出现，持续探测
  setInterval(ensureVideo, 2000);
  ensureVideo();

  // 若之前已保存过房间配置，自动重连
  chrome.storage?.local?.get(['serverUrl', 'room', 'pass', 'autoJoin'], (cfg) => {
    if (cfg.autoJoin && cfg.serverUrl && cfg.room) {
      state.serverUrl = cfg.serverUrl;
      state.room = cfg.room;
      state.pass = cfg.pass || '';
      connect();
    }
  });

  function log(...args) {
    console.log('[一起看]', ...args);
  }

})();
